import tkinter as tk
import math

X1 = 0
X2 = 0
X3 = 0
X4 = 0
X5 = 0


def calculate():
    solution = X1 / 4.8 + X2 / 2.4 + X3 / 1.6 + X4 / 1.2 + X5 / 0.96
    solution = math.ceil(solution)
    l6.config(text=str(solution))


def add1():
    global X1
    X1 = X1 + 1
    l1.config(text=str(X1))


def add2():
    global X2
    X2 = X2 + 1
    l2.config(text=str(X2))


def add3():
    global X3
    X3 = X3 + 1
    l3.config(text=str(X3))


def add4():
    global X4
    X4 = X4 + 1
    l4.config(text=str(X4))


def add5():
    global X5
    X5 = X5 + 1
    l5.config(text=str(X5))


def sub1():
    global X1
    if X1 > 0:
        X1 = X1 - 1
        l1.config(text=str(X1))


def sub2():
    global X2
    if X2 > 0:
        X2 = X2 - 1
        l2.config(text=str(X2))


def sub3():
    global X3
    if X3 > 0:
        X3 = X3 - 1
        l3.config(text=str(X3))


def sub4():
    global X4
    if X4 > 0:
        X4 = X4 - 1
        l4.config(text=str(X4))


def sub5():
    global X5
    if X5 > 0:
        X5 = X5 - 1
        l5.config(text=str(X5))


window = tk.Tk()

lheader = tk.Label(window, text="Wastepack Calculator")
lheader.grid(columnspan=5, row=1)

add1 = tk.Button(window, text="+1", command=add1)
add1.grid(column=1, row=2)

l1 = tk.Label(window, width=5, height=1, text="0")
l1.grid(column=1, row=3)

sub1 = tk.Button(window, text="-1", command=sub1)
sub1.grid(column=1, row=4)

add2 = tk.Button(window, text="+1", command=add2)
add2.grid(column=2, row=2)

l2 = tk.Label(window, width=5, height=1, text="0")
l2.grid(column=2, row=3)

sub2 = tk.Button(window, text="-1", command=sub2)
sub2.grid(column=2, row=4)

add3 = tk.Button(window, text="+1", command=add3)
add3.grid(column=3, row=2)

l3 = tk.Label(window, width=5, height=1, text="0")
l3.grid(column=3, row=3)

sub3 = tk.Button(window, text="-1", command=sub3)
sub3.grid(column=3, row=4)

add4 = tk.Button(window, text="+1", command=add4)
add4.grid(column=4, row=2)

l4 = tk.Label(window, width=5, height=1, text="0")
l4.grid(column=4, row=3)

sub4 = tk.Button(window, text="-1", command=sub4)
sub4.grid(column=4, row=4)

add5 = tk.Button(window, text="+1", command=add5)
add5.grid(column=5, row=2)

l5 = tk.Label(window, width=5, height=1, text="0")
l5.grid(column=5, row=3)

sub5 = tk.Button(window, text="-1", command=sub5)
sub5.grid(column=5, row=4)

calc = tk.Button(window, text="Calculate", command=calculate)
calc.grid(columnspan=2, row=5)

l6 = tk.Label(window, width=10, height=1, text="0")
l6.grid(column=3, columnspan=3, row=5)

window.mainloop()
